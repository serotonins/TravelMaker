-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: travelmaker-database.cx6k2mygmj69.ap-northeast-2.rds.amazonaws.com    Database: travelmaker
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `record`
--

DROP TABLE IF EXISTS `record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `record` (
  `create_time` datetime(6) DEFAULT NULL,
  `record_id` bigint NOT NULL,
  `dtype` varchar(31) NOT NULL,
  `emoji` varchar(255) DEFAULT NULL,
  `img_url` varchar(255) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `video_thumbnail_url` varchar(255) DEFAULT NULL,
  `video_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `record`
--

LOCK TABLES `record` WRITE;
/*!40000 ALTER TABLE `record` DISABLE KEYS */;
INSERT INTO `record` VALUES ('2024-02-15 21:37:10.953338',155,'P','\"HAPPY\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/SNOW_20230923_135452_680.jpg','웅장해지는 경치','웅장해지는 경치','',''),('2024-02-15 21:37:37.607852',156,'P','\"SMILE\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/SNOW_20230923_122126_388.jpg','쁘이','쁘이','',''),('2024-02-15 21:39:30.077995',157,'P','\"HAPPY\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/SNOW_20230923_135329_970.jpg','돌탑의 수호자','돌탑의 수호자','',''),('2024-02-15 21:39:54.727476',158,'P','\"SOSO\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/SNOW_20230923_103336_991.jpg','금오산 폭포','금오산 폭포','',''),('2024-02-15 21:49:28.818740',159,'P','\"HAPPY\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/SNOW_20230103_143212_226.jpg','가오리 기여웡','가오리 기여웡','',''),('2024-02-15 21:50:04.780537',160,'P','\"SMILE\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/SNOW_20230103_142950_051.jpg','대왕 고래','대왕 고래','',''),('2024-02-15 21:50:46.221374',161,'P','\"ANGRY\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/SNOW_20230103_141407_283.jpg','해파리','해파리','',''),('2024-02-15 21:51:11.502457',162,'P','\"SOSO\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/1703947810044.jpg','눈이 이따시만큼 옴ㅋ','눈이 이따시만큼 옴ㅋ','',''),('2024-02-15 21:52:00.817628',163,'P','\"SOSO\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/SNOW_20230103_142621_969.jpg','수영하고싶다','수영하고싶다','',''),('2024-02-15 21:52:21.410730',164,'P','\"HAPPY\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/thumbnail_1708001505974.jpg','눈올 때  따습게 불로 지져봤다','눈올 때  따습게 불로 지져봤다','','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/videos/20240210_183955.mp4'),('2024-02-15 21:52:52.699944',165,'P','\"HAPPY\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/IMG_20240212_011113_010.jpg','사진도 찍음 ㅎㅋ','사진도 찍음 ㅎㅋ','',''),('2024-02-15 21:55:10.092213',166,'P','\"SMILE\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/20240209_135917.jpg','이거 내가 만들거임','이거 내가 만들거임','',''),('2024-02-15 21:56:15.519799',167,'P','\"HAPPY\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/1703947809695.jpg','재료사러 나옴','재료사러 나옴','',''),('2024-02-15 21:59:18.636510',168,'P','\"HAPPY\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/%EB%8B%A4%EC%9A%B4%EB%A1%9C%EB%93%9C%ED%8C%8C%EC%9D%BC.jpg','애견카페 기염 강쥐','애견카페 기염 강쥐','',''),('2024-02-15 22:00:13.889820',169,'P','\"HAPPY\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/20240211_111351.jpg','보더콜리랑 산책함','보더콜리랑 산책함','',''),('2024-02-15 22:03:43.601727',170,'P','\"SMILE\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/20240212_182803.jpg','치킨도 먹음','치킨도 먹음','',''),('2024-02-15 22:04:15.540170',171,'P','\"SOSO\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/20240210_084109.jpg','여기서 수제버거 만들더라','여기서 수제버거 만들더라','',''),('2024-02-15 22:05:28.201850',172,'P','\"SMILE\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/thumbnail_1708002278975.jpg','지지짖 기대됨','지지짖 기대됨','','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/videos/20230928_201604.mp4'),('2024-02-15 22:28:18.223456',173,'P','\"SAD\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/20240215_222226.jpg','여행 중 만난 우건쿤','여행 중 만난 우건쿤','',''),('2024-02-15 22:29:27.655599',174,'P','\"SMILE\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/20240215_222226.jpg','코딩하는 사람 만남','코딩하는 사람 만남','',''),('2024-02-15 22:29:46.138679',175,'P','\"SAD\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/thumbnail_1708003778437.jpg','한잔 때리고','한잔 때리고','','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/videos/20240215_222109.mp4'),('2024-02-15 22:30:00.318981',176,'P','\"ANGRY\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/20240215_222042.jpg','같이 사진도 박고','같이 사진도 박고','',''),('2024-02-15 22:35:12.210468',177,'P','\"ANGRY\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/20240215_222042.jpg','반말하는 녀석 만남','반말하는 녀석 만남','',''),('2024-02-15 22:35:36.698122',178,'P','\"ANGRY\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/20240215_222301.jpg','반말하는 녀석 하나 더 있음','반말하는 녀석 하나 더 있음','',''),('2024-02-15 22:35:52.088337',179,'P','\"SMILE\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/thumbnail_1708004144223.jpg','같이 한잔 때림','같이 한잔 때림','','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/videos/20240215_222109.mp4'),('2024-02-15 22:53:33.137033',180,'P','\"SMILE\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/20240215_222042.jpg','외국인인데 현지인 만남','외국인인데 현지인 만남','',''),('2024-02-15 22:54:11.345615',181,'P','\"SMILE\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/thumbnail_1708005221086.jpg','한잔 맛쉬께 무꺼떠욤','한잔 맛쉬께 무꺼떠욤','','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/videos/20240215_222109.mp4'),('2024-02-16 02:33:18.814303',182,'P','\"HAPPY\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/Screenshot_20240215_202732_travelmaker.jpg','ㅎㅎ','ㅎㅎ','',''),('2024-02-16 02:33:40.161889',183,'P','\"SMILE\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/thumbnail_1708018407666.jpg','ㅋㅋ','ㅋㅋ','','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/videos/20240215_145222.mp4'),('2024-02-16 02:35:53.318851',184,'P','\"SAD\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/Screenshot_20231209_174113_Toss.jpg','ㅓㅓ','ㅓㅓ','',''),('2024-02-16 02:36:17.653606',185,'P','\"SMILE\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/thumbnail_1708018560151.jpg','ㅋㅋ','ㅋㅋ','','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/videos/20240211_180822.mp4'),('2024-02-16 10:40:03.544899',186,'P','\"HAPPY\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/thumbnail_1708047599563.jpg','좋았어요','좋았어요','','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/videos/%EC%98%81%E3%85%8E%EC%83%81.mp4'),('2024-02-16 10:42:48.123078',187,'P','\"SMILE\"','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/KakaoTalk_20240216_092024614_01.jpg','친절한 우건씨','친절한 우건씨','','');
/*!40000 ALTER TABLE `record` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 11:15:17
