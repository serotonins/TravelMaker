-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: travelmaker-database.cx6k2mygmj69.ap-northeast-2.rds.amazonaws.com    Database: travelmaker
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `trust` double DEFAULT NULL,
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `phone` varchar(15) DEFAULT NULL,
  `birth` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `nation` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `town` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `fcmtoken` tinytext,
  `gender` enum('MALE','FEMALE') DEFAULT NULL,
  `profile_imgurl` tinytext,
  `role` enum('USER','ADMIN') NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (NULL,1,'01012345678','1998','test@test.com','대한민국','테스트 계정','$2a$10$KzIQ3dPDhUpQggWPi7BF0.LRBvfqVgRRrFZw4t5s2ZJX8dX/UFDXy','구미시 인동 00','testid123',NULL,'MALE','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/%EA%B0%95%EC%95%84%EC%A7%801.png','USER'),(NULL,2,'01047561803','1998',NULL,'Korea','이우건','$2a$10$TVZAqpHwRqUXDluv8yM5pu1mNj4QJbkjUTlfJG.xP9jba4iQ/p./i','경기 광명시 하안동 864','bome519','eCbro7XzS-SfPizo7Rjsew:APA91bFo5T99E1zgww9GsHMqZmGxWS5z8toGjjG5HLkx8MiTxI8INenF2fi6skgZ79QdxOrCKIFokVBRBl0FYfJToXoSBHQUHuZpVTEOtg0ytbKtG93HTAMcF4myYQNTCXuBpjGfertX','MALE','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/1666973350220.jpg','USER'),(NULL,3,'01012345678','1998','','Korea','김인호','$2a$10$ncG16t3FtGCW6RdN9yUUpeIYYvNdNH94RpzBsNZL1hCa.QVWG3YAS','구미시 인동 01','inhoid123',NULL,'MALE','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/%EC%9D%B8%ED%98%B8.png','USER'),(NULL,4,'01012345678','1999','','Korea','최지수','$2a$10$vkQHAp8ae1.935QnIV8.kuHFfgJ/a6LJiFAAGn2C.lxN6vu2g.E82','구미시 인동 02','jisuid123','fDnWN2WESXyz4Ji-hY8zGx:APA91bEFF8ZqYfzCzd2LLn6fZQXjev25eDopvUKaH7gpYRR2J3LQw4nRpPgcOG5QYdr7ewT6x58QIsKkxT77svDvzkXgyyEtw0mNMNmyg1PvJtACHYJYndC2NWeZXpT-IZoOe5A1e-_2','FEMALE','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/%EC%A7%80%EC%88%98.png','USER'),(NULL,5,'01055923576','2001',NULL,'GS25 녹번현대점','기미노','$2a$10$DMzyKUImCFWn3DmaGIQleOXJRQj4Fr1ZJnRgiYSnKQu2I5lU/3Kr6','서울 은평구 녹번동 278-1','inho123','dGvgKXjjT8GJOG8Pi7cOi5:APA91bElLz9FsoykAnS-_Lyi8ZL4Aqp0i1Y2fazc3ImInxI16QH25Z9dsZcdfjBJgFb8wBdEzEvReh_wGl1raPtxB8OpnPQVLDhW5B722BDJtJA8eKEhDVAcB1HRDwXF_EdEK_XMhjT3','MALE','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/Screenshot_20240215_005930_Instagram.jpg','USER'),(NULL,6,'01012345678','1994','','Korea','최지원','$2a$10$XwEWAVV8dbQ7qp3LG373AeofxMSiq1ua8RxAaLO8vsho64T9uRir.','구미시 인동 03','jiwonid123','dibwwf3_Roatgo_xtHW2gu:APA91bF5HfSKPIOS6_uTj73bdwe3dQ0UHA4JuXGSd3U1WJvBJkv0zfw8ZPyw5Wx6o9jToAP7St4ZmOWrPgnCGvK579J-WhMHfc73ozju8Pke88ln8AYPZhey4lgzXmJgoQNFaucT7pU2','FEMALE','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/%EC%A7%80%EC%9B%90.png','USER'),(NULL,7,'01012345678','1995','','Korea','서현재','$2a$10$B.BxNuRK59f9tS0r0UytEOxOyu91H49W6gBOtxyLFY4tVq14Klvt.','구미시 인동 04','hyunjaeid123','e9uVHxf4T1ObqknClnpuPc:APA91bFmUZtKGlH0Hb2yF_-rEz14_jNv5uvkqsCBEsHQRhtBtAppOlFhcPRV9iD02EjPdP_EI1XS5Lz3DnHRAvxI-4HMwjGwlUWTLJtCFVpaB28ajGCAb9ksubdBCXKauPqxTj2i1Ajb','MALE','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/%ED%98%84%EC%9E%AC.png','USER');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 11:15:16
