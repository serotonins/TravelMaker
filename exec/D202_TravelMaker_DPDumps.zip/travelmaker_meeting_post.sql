-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: travelmaker-database.cx6k2mygmj69.ap-northeast-2.rds.amazonaws.com    Database: travelmaker
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `meeting_post`
--

DROP TABLE IF EXISTS `meeting_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting_post` (
  `is_finish` bit(1) DEFAULT b'0',
  `is_meeting_finish` bit(1) DEFAULT b'0',
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `member_max` int DEFAULT NULL,
  `native_min` int DEFAULT NULL,
  `traveler_min` int DEFAULT NULL,
  `auth_date` datetime(6) DEFAULT NULL,
  `deadline` datetime(6) DEFAULT NULL,
  `end_date` datetime(6) DEFAULT NULL,
  `meeting_post_id` bigint NOT NULL AUTO_INCREMENT,
  `start_date` datetime(6) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `img_url_main` varchar(255) DEFAULT NULL,
  `img_url_sub` varchar(255) DEFAULT NULL,
  `img_url_thr` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `town` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`meeting_post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting_post`
--

LOCK TABLES `meeting_post` WRITE;
/*!40000 ALTER TABLE `meeting_post` DISABLE KEYS */;
INSERT INTO `meeting_post` VALUES (_binary '',_binary '\0',36.105963843675205,128.41778378099303,3,1,1,NULL,'2024-02-16 12:00:00.000000','2024-02-17 00:00:00.000000',2,'2024-02-17 00:00:00.000000','나랑 같이 피자 드실? ','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/20230612_A5Qaqy05.jpg','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/20230619_hybtjkBv.jpg','','도미노피자 구미인동점','도미노 피자 조지러갈 사람','경북 구미시 진평동 630-7'),(_binary '',_binary '\0',36.10187813781035,128.4239353637551,3,2,1,NULL,'2024-02-18 17:20:00.000000','2024-02-20 00:00:00.000000',4,'2024-02-19 00:00:00.000000','ㅎㅎ','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/SNOW_20230402_211816_578.jpg','','','다이소 구미인의점','다이소에서 커피한잔','경북 구미시 인의동 844-6'),(_binary '\0',_binary '\0',36.1071765439437,128.417878870048,4,2,2,NULL,'2024-02-17 16:20:00.000000','2024-02-24 00:00:00.000000',5,'2024-02-18 00:00:00.000000','슬픈 영화 보면서 같이 울어볼까요~~?','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/IMG_20240104_231414_125.jpg','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/Screenshot_20240213_193750_Gallery.jpg','','메가박스 구미강동','메가박스 영화 문화 체험할 분? ','경북 구미시 진평동 1023-2'),(_binary '\0',_binary '\0',36.1071765439437,128.417878870048,3,1,1,NULL,'2024-02-16 12:00:00.000000','2024-02-17 00:00:00.000000',6,'2024-02-17 00:00:00.000000','재밌는 영화 봅시데이','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/BEPryJ77um50zJhNfI7Of5DICqbDTTsiP7AOF4vXZwgoXyi4NG7BI6KKLfyt7hToD2W_glT8RAVzVmEoOEz9wQ.webp','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/120601008.2.jpg','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/EC538420-C9B7-4EEF-A30C-F650D4E53655.jpg','메가박스 구미강동','같이 영화 조지실 분?','경북 구미시 진평동 1023-2'),(_binary '',_binary '\0',36.10670529079354,128.41848449877583,5,2,3,NULL,'2024-02-24 16:00:00.000000','2024-02-29 00:00:00.000000',7,'2024-02-25 00:00:00.000000','투썸에서 출발하고, 여기저기 진평 산책해요','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/20240211_163837.jpg','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/20231230_160629.jpg','','투썸플레이스 구미인동점','카페서 출발] 진평 동네 투어 ','경북 구미시 진평동 1026-4'),(_binary '',_binary '\0',36.10774599974,128.411168345998,2,1,1,NULL,'2024-02-18 23:55:00.000000','2024-02-20 00:00:00.000000',8,'2024-02-19 00:00:00.000000','두통을 나눠요','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/1669183631313.png','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/SNOW_20240215_145251_885.jpg','','삼성전자 제2구미캠퍼스','싸피에서 같이 코딩할분','경북 구미시 임수동 94-1'),(_binary '\0',_binary '\0',36.103853748445,128.418743039696,3,2,1,NULL,'2024-02-25 21:00:00.000000','2024-02-27 00:00:00.000000',9,'2024-02-26 00:00:00.000000','치킨 and 맥주','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/Screenshot_20230703_152137_NAVER.jpg','','','처갓집양념치킨 진평점','치맥으로 우리 서로 가까워져요','경북 구미시 진평동 458'),(_binary '',_binary '\0',35.3832201859007,128.471784568202,3,2,1,NULL,'2024-02-19 19:00:00.000000','2024-02-23 00:00:00.000000',11,'2024-02-22 00:00:00.000000','ㅋㅋ','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/%EC%9D%B4%EC%9A%B0%EA%B1%B4%20copy.jpg','','','창녕낙동강 유채단지','ㅋㅋ','경남 창녕군 남지읍 남지리'),(_binary '',_binary '\0',36.1026396976303,128.421270753568,3,1,2,NULL,'2024-02-20 18:45:00.000000','2024-02-22 00:00:00.000000',13,'2024-02-21 00:00:00.000000','배고파요','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/1708018873089.jpg','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/1708018870140.jpg','','차이&웍','여기 정말 혜자에요!','경북 구미시 진평동 563-4'),(_binary '\0',_binary '\0',36.1074213953458,128.419118144131,2,1,1,NULL,'2024-02-19 21:00:00.000000','2024-02-21 00:00:00.000000',14,'2024-02-20 00:00:00.000000','설렁탕','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/SNOW_20230703_201451_006.jpg','','','더벤티 구미인동점','설렁탕','경북 구미시 황상동 313-5');
/*!40000 ALTER TABLE `meeting_post` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 11:15:16
