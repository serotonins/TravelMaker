-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: travelmaker-database.cx6k2mygmj69.ap-northeast-2.rds.amazonaws.com    Database: travelmaker
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `pamphlet`
--

DROP TABLE IF EXISTS `pamphlet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pamphlet` (
  `love` int DEFAULT NULL,
  `create_time` datetime(6) DEFAULT NULL,
  `pamphlet_id` bigint NOT NULL,
  `dtype` varchar(31) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pamphlet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pamphlet`
--

LOCK TABLES `pamphlet` WRITE;
/*!40000 ALTER TABLE `pamphlet` DISABLE KEYS */;
INSERT INTO `pamphlet` VALUES (0,'2024-02-15 21:35:42.856407',104,'P','금오산 정복기'),(0,'2024-02-15 21:48:49.816130',105,'P','오키나와 수족관'),(0,'2024-02-15 21:49:19.016643',106,'P','구미에도 눈이!?'),(0,'2024-02-15 22:29:08.911386',113,'P','ssafy 여행 중'),(0,'2024-02-15 22:32:44.944705',114,'P','ssafy 여행 중'),(0,'2024-02-15 22:43:50.171314',115,'P','낙동강 가보까'),(0,'2024-02-15 22:46:29.970656',116,'P','구미여행 중'),(0,'2024-02-16 02:32:34.463117',117,'P','구미 싸피 가볼까?'),(0,'2024-02-16 09:37:10.950380',118,'P','히죽히죽'),(0,'2024-02-16 10:39:44.383834',119,'P','경치좋은 구미');
/*!40000 ALTER TABLE `pamphlet` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 11:15:20
