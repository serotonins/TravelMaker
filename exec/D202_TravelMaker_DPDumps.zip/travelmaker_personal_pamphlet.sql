-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: travelmaker-database.cx6k2mygmj69.ap-northeast-2.rds.amazonaws.com    Database: travelmaker
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `personal_pamphlet`
--

DROP TABLE IF EXISTS `personal_pamphlet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_pamphlet` (
  `pamphlet_id` bigint NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `categories` varchar(255) DEFAULT NULL,
  `is_finish` bit(1) DEFAULT NULL,
  `repre_img_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pamphlet_id`),
  KEY `FKestei272ysk0qat5f55qnpluh` (`user_id`),
  CONSTRAINT `FKddpb4syv2lwhe6gfylhkaq76f` FOREIGN KEY (`pamphlet_id`) REFERENCES `pamphlet` (`pamphlet_id`),
  CONSTRAINT `FKestei272ysk0qat5f55qnpluh` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_pamphlet`
--

LOCK TABLES `personal_pamphlet` WRITE;
/*!40000 ALTER TABLE `personal_pamphlet` DISABLE KEYS */;
INSERT INTO `personal_pamphlet` VALUES (104,7,'[\"healing\",\"active\",\"picture\",\"nature\"]',_binary '','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/SNOW_20230923_135026_222.jpg'),(105,7,'[\"nature\",\"picture\",\"active\",\"culture\",\"rest\"]',_binary '','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/SNOW_20230103_140451_272.jpg'),(106,5,'[\"healing\",\"culture\"]',_binary '','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/20231230_170035%280%29.jpg'),(113,4,'[\"picture\",\"active\"]',_binary '','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/SNOW_20240215_145251_885.jpg'),(114,4,'[\"healing\",\"active\"]',_binary '','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/SNOW_20240215_145251_885.jpg'),(115,7,'[\"healing\",\"active\"]',_binary '','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/Screenshot_20240115_165335_Samsung%20Members.jpg'),(116,7,'[\"taste\",\"picture\",\"rest\"]',_binary '','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/1354690336947029.jpg'),(117,2,'[\"active\",\"picture\",\"nature\",\"culture\"]',_binary '\0','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/SNOW_20240215_145251_885.jpg'),(118,7,'[\"taste\",\"active\",\"picture\",\"healing\"]',_binary '\0','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/20240215_222301.jpg'),(119,7,'[\"active\",\"picture\",\"culture\"]',_binary '','https://d202-travelmaker-bucket.s3.ap-northeast-2.amazonaws.com/images/KakaoTalk_20240216_092024614.jpg');
/*!40000 ALTER TABLE `personal_pamphlet` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 11:15:15
