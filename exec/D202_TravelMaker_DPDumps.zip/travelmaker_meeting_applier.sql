-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: travelmaker-database.cx6k2mygmj69.ap-northeast-2.rds.amazonaws.com    Database: travelmaker
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `meeting_applier`
--

DROP TABLE IF EXISTS `meeting_applier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting_applier` (
  `is_head` bit(1) DEFAULT NULL,
  `is_native` bit(1) DEFAULT NULL,
  `meeting_applier_id` bigint NOT NULL,
  `meeting_post_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`meeting_applier_id`),
  UNIQUE KEY `UKsvvyqwd2fiu2uhhl0hqw3pafy` (`user_id`,`meeting_post_id`),
  KEY `FKpie8rfkjduk5dp1jgcogcxfw0` (`meeting_post_id`),
  CONSTRAINT `FKpie8rfkjduk5dp1jgcogcxfw0` FOREIGN KEY (`meeting_post_id`) REFERENCES `meeting_post` (`meeting_post_id`),
  CONSTRAINT `FKpps6kt8m0sxpfqwv9capi3a81` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting_applier`
--

LOCK TABLES `meeting_applier` WRITE;
/*!40000 ALTER TABLE `meeting_applier` DISABLE KEYS */;
INSERT INTO `meeting_applier` VALUES (_binary '',_binary '\0',2,2,6),(_binary '\0',_binary '\0',3,2,2),(_binary '\0',_binary '\0',53,2,5),(_binary '',_binary '\0',102,4,2),(_binary '',_binary '\0',103,5,5),(_binary '',_binary '\0',104,6,7),(_binary '\0',_binary '\0',105,5,2),(_binary '',_binary '\0',106,7,5),(_binary '\0',_binary '\0',107,7,7),(_binary '',_binary '\0',152,8,2),(_binary '',_binary '\0',153,9,2),(_binary '\0',_binary '\0',154,8,4),(_binary '',_binary '\0',156,11,2),(_binary '\0',_binary '\0',158,4,5),(_binary '',_binary '\0',160,13,2),(_binary '',_binary '\0',161,14,4),(_binary '\0',_binary '\0',162,13,6),(_binary '\0',_binary '\0',163,13,7);
/*!40000 ALTER TABLE `meeting_applier` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 11:15:19
